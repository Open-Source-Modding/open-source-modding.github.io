# Disrupt Engine — Asset Pipeline Format Mapping

> **Source**: OCR of WDL dev pipeline reference (`wdl_format_info.txt`), cross-referenced with community findings.

The Disrupt engine converts authoring formats into runtime binary formats during the build process (`PreparePlatformData64.exe`). Here is the mapping from source/authoring format to compiled/runtime format.

## Format Conversions

| Authoring Format | Runtime Format | Description |
|------------------|----------------|-------------|
| `material.xml` | `.material.bin` | Material descriptors (TAM v7 binary, magic `0x004D4154`) |
| `.mac` | `_mab` | MAB animation clips |
| `.seq` | `.cseq` | Cutscene sequences (QES binary format) |
| `_move.xml` | `_move.bin` | Movement/locomotion data |
| `_markup` | `_markup.bin` | UI markup data |
| `.1ft` | `.xIf` | Physics fixture data |
| `.tree_xml` / `.impostor.xml` | `.bin` | Vegetation tree + impostor data |
| `.bik` | `.bik` / `.biklight` | Bink video (light variant for pre-rendered sequences) |
| `.fba` / `.animset` | `.dpax` | Animation blend trees / animation sets |
| `-dpds` | `_dpdx` | Depload dependency data (compiled) |

## Other Asset Categories

| Category | Notes |
|----------|-------|
| Road/spline | Geometry + loft (graphics/physics) |
| Sound banks | `.bnk` / `.spk` audio containers |
| Character customization | Graphickit parts, clothing definitions |
| Lua scripts | Compiled to bytecode (not source — game reads compiled) |
| World/terrain | Terrain chunks, navmesh, world generation |
| Specialized Havok variants | Physics data (collision, ragdoll, vehicle) |
| AI/world systems | Behavior trees, spawn tables, traffic patterns |

## Key Notes

- **`.fx` shader source is NOT compiled** — the game reads compiled shaders from `shadersobj.dat`, not `.fx` source from `shaders.dat`
- **`.material.bin` uses TAM v7** — magic bytes `54 41 4D 00` (little-endian). Beta builds used v5 big-endian (`00 4D 41 54`)
- **`.cseq` cutscenes** are QES (Quake Engine Sequence) binary format — 307 files in WD1 unpacked data
- **Lua scripts** are compiled to bytecode at build time — decompilation required for editing
- **Depload** (`_dpds` → `_dpdx`) is the dependency preload manifest — see [Depload Format](../depload-format.md)

## Related

- [Material Binary Format](material-bin-format.md) — TAM v7 structure
- [MAB Animation Format](mab-format.md) — animation clip format
- [Depload Format](../depload-format.md) — dependency preload tables
- [Shader Editing Workflow](shader-editing-workflow.md) — why .fx source isn't used
